<?php
declare(strict_types=1);

require_once __DIR__ . '/../database/conexion-db.php';
require_once __DIR__ . '/../models/Pregunta.php';
require_once __DIR__ . '/../helpers/DibujoHelper.php';

class EncuestasController
{
    private mysqli $db;

    public function __construct()
    {
        // Usamos la conexión clásica
        global $conn;
        $this->db = $conn;
    }

    /* ==========================================================
       OBTENER ENCUESTA POR NIVEL
    ========================================================== */
    public function obtenerEncuestaPorNivel(string $nivel): array
    {
        $nivel = strtolower(trim($nivel));

        $niveles = [
            'preescolar'   => 1,
            'primaria'     => 4,
            'secundaria'   => 5,
            'preparatoria' => 6,
        ];

        $idEncuesta = $niveles[$nivel] ?? 4;

        return [
            'id_encuesta' => $idEncuesta,
            'nivel'       => $nivel,
            'preguntas'   => $this->obtenerPreguntas($idEncuesta)
        ];
    }

    /* ==========================================================
       CREAR REGISTRO DE USUARIO ENCUESTA (Sesión)
    ========================================================== */
    private function crearUsuarioEncuesta(int $idEncuesta, int $idEscuela): int
    {
        $sql = "INSERT INTO encuestas_usuarios
                (id_encuesta, id_escuela, fecha_inicio)
                VALUES (?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        if (!$stmt) {
            throw new Exception("Error al preparar encuestas_usuarios: " . $this->db->error);
        }

        $stmt->bind_param("ii", $idEncuesta, $idEscuela);

        if (!$stmt->execute()) {
            throw new Exception("No se pudo crear el registro de encuestas_usuarios");
        }

        $id = $this->db->insert_id;
        $stmt->close();
        return $id;
    }

    /* ==========================================================
       OBTENER PREGUNTAS
    ========================================================== */
    public function obtenerPreguntas(int $id_encuesta): array
    {
        $sql = "
            SELECT 
                p.id_pregunta,
                p.id_encuesta,
                p.texto_pregunta,
                p.tipo_pregunta,
                p.orden,
                p.icono AS icono_pregunta,
                o.id_opcion,
                o.texto_opcion,
                o.icono AS icono_opcion
            FROM preguntas p
            LEFT JOIN opciones_respuesta o ON p.id_pregunta = o.id_pregunta
            WHERE p.id_encuesta = ?
            ORDER BY p.orden ASC, o.id_opcion ASC
        ";

        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("i", $id_encuesta);
        $stmt->execute();

        $res = $stmt->get_result();
        $preguntas = [];

        while ($row = $res->fetch_assoc()) {
            $pid = (int)$row['id_pregunta'];

            if (!isset($preguntas[$pid])) {
                // Aseguramos que el icono de la pregunta se pase correctamente
                $row['icono'] = $row['icono_pregunta'];
                $preguntas[$pid] = new Pregunta($row);
            }

            if ($row['id_opcion'] !== null) {
                // Aseguramos que el icono de la opción se pase correctamente
                $row['icono'] = $row['icono_opcion'];
                $preguntas[$pid]->agregarOpcion($row);
            }
        }

        $stmt->close();
        return array_values($preguntas);
    }

    /* ==========================================================
       GUARDAR RESPUESTAS (MODIFICADO PARA GÉNERO)
    ========================================================== */
    public function enviarRespuestas(array $payload): array
    {
        $idEncuesta = (int)($payload['id_encuesta'] ?? 0);
        if ($idEncuesta === 0) {
            throw new Exception('ID de encuesta inválido');
        }

        $idEscuela = (int)($payload['id_escuela'] ?? 1);
        
        // 1. RECIBIR GÉNERO (Por defecto 'X' si no viene)
        $genero = isset($payload['genero']) ? substr(trim($payload['genero']), 0, 1) : 'X';
        if (!in_array($genero, ['M', 'F', 'X'])) {
            $genero = 'X';
        }

        // Crear la sesión
        $idUsuarioEncuesta = $this->crearUsuarioEncuesta($idEncuesta, $idEscuela);

        $respuestas = $payload['respuestas'] ?? [];
        $dibujos    = $payload['dibujos']    ?? [];

        $this->db->begin_transaction();

        try {
            $total = 0;

            /* ---------------- TEXTO ---------------- */
            if (!empty($respuestas['texto'])) {
                foreach ($respuestas['texto'] as $idPregunta => $texto) {
                    $this->guardarTexto(
                        $idUsuarioEncuesta,
                        $idEncuesta,
                        (int)$idPregunta,
                        $idEscuela,
                        trim($texto),
                        $genero // Pasamos género
                    );
                    $total++;
                }
            }

            /* ---------------- OPCIÓN ---------------- */
            if (!empty($respuestas['opcion'])) {
                foreach ($respuestas['opcion'] as $idPregunta => $data) {
                    $this->guardarOpcion(
                        $idUsuarioEncuesta,
                        $idEncuesta,
                        (int)$idPregunta,
                        $idEscuela,
                        (int)$data['id_opcion'],
                        $data['texto_otro'] ?? null,
                        $genero // Pasamos género
                    );
                    $total++;
                }
            }

            /* ---------------- MULTIPLE ---------------- */
            if (!empty($respuestas['multiple'])) {
                foreach ($respuestas['multiple'] as $idPregunta => $ops) {
                    foreach ($ops as $opcion) {
                        $this->guardarOpcion(
                            $idUsuarioEncuesta,
                            $idEncuesta,
                            (int)$idPregunta,
                            $idEscuela,
                            (int)$opcion['id_opcion'],
                            null,
                            $genero // Pasamos género
                        );
                        $total++;
                    }
                }
            }

            /* ---------------- RANKING ---------------- */
            if (!empty($respuestas['ranking'])) {
                foreach ($respuestas['ranking'] as $idPregunta => $lista) {
                    foreach ($lista as $item) {
                        if (!isset($item['id_opcion'], $item['posicion'])) continue;

                        // Nota: Ranking no lleva género en su tabla específica por ahora, 
                        // pero está vinculado por id_usuario_encuesta
                        $sql = "INSERT INTO respuestas_ranking
                                (id_usuario_encuesta, id_pregunta, id_opcion, posicion)
                                VALUES (?, ?, ?, ?)";

                        $stmt = $this->db->prepare($sql);
                        $stmt->bind_param("iiii",
                            $idUsuarioEncuesta,
                            $idPregunta,
                            $item['id_opcion'],
                            $item['posicion']
                        );
                        $stmt->execute();
                        $stmt->close();

                        $total++;
                    }
                }
            }

            /* ---------------- DIBUJOS ---------------- */
            if (!empty($dibujos)) {
                foreach ($dibujos as $idPregunta => $base64) {
                    $this->guardarDibujo(
                        $idUsuarioEncuesta,
                        $idEncuesta,
                        (int)$idPregunta,
                        $idEscuela,
                        $base64,
                        $genero // Pasamos género
                    );
                    $total++;
                }
            }

            $this->db->commit();

            return [
                'success' => true,
                'total'   => $total
            ];

        } catch (Throwable $e) {
            $this->db->rollback();
            throw $e;
        }
    }

    /* ==========================================================
       MÉTODOS PRIVADOS DE GUARDAR (Con Género)
    ========================================================== */

    private function guardarTexto(
        int $idUsuarioEncuesta,
        int $idEncuesta,
        int $idPregunta,
        int $idEscuela,
        string $texto,
        string $genero
    ): void {
        // Agregamos campo 'genero'
        $sql = "INSERT INTO respuestas_usuario
            (id_usuario_encuesta, id_encuesta, id_pregunta, respuesta_texto, id_escuela, genero, fecha_respuesta)
            VALUES (?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        // Tipos: i=int, s=string -> iiisis
        $stmt->bind_param("iiisis",
            $idUsuarioEncuesta,
            $idEncuesta,
            $idPregunta,
            $texto,
            $idEscuela,
            $genero
        );
        $stmt->execute();
        $stmt->close();
    }

    private function guardarOpcion(
        int $idUsuarioEncuesta,
        int $idEncuesta,
        int $idPregunta,
        int $idEscuela,
        int $idOpcion,
        ?string $textoOtro = null,
        string $genero = 'X'
    ): void {
        // Agregamos campo 'genero'
        $sql = "INSERT INTO respuestas_usuario
            (id_usuario_encuesta, id_encuesta, id_pregunta, id_opcion, respuesta_texto, id_escuela, genero, fecha_respuesta)
            VALUES (?, ?, ?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        // Tipos: iiiisis
        $stmt->bind_param("iiiisis",
            $idUsuarioEncuesta,
            $idEncuesta,
            $idPregunta,
            $idOpcion,
            $textoOtro,
            $idEscuela,
            $genero
        );
        $stmt->execute();
        $stmt->close();
    }

    private function guardarDibujo(
        int $idUsuarioEncuesta,
        int $idEncuesta,
        int $idPregunta,
        int $idEscuela,
        string $base64,
        string $genero
    ): void {
        if (strlen($base64) < 50) return;

        // Agregamos campo 'genero'
        $sql = "INSERT INTO respuestas_usuario
                (id_usuario_encuesta, id_encuesta, id_pregunta, id_escuela, genero, fecha_respuesta)
                VALUES (?, ?, ?, ?, ?, NOW())";

        $stmt = $this->db->prepare($sql);
        // Tipos: iiiis
        $stmt->bind_param("iiiis",
            $idUsuarioEncuesta,
            $idEncuesta,
            $idPregunta,
            $idEscuela,
            $genero
        );
        $stmt->execute();

        $idRespuesta = $this->db->insert_id;
        $stmt->close();

        // Guardar archivo físico
        $ruta = DibujoHelper::guardar($base64, $idRespuesta);

        $sql = "UPDATE respuestas_usuario SET dibujo_ruta=? WHERE id_respuesta_usuario=?";
        $stmt = $this->db->prepare($sql);
        $stmt->bind_param("si", $ruta, $idRespuesta);
        $stmt->execute();
        $stmt->close();
    }
}