<footer class="footer-simpinna footer-admin">
  <div class="footer-container">

    <div class="footer-logo">
      <img
        src="/front-end/assets/img/global/tkt-pueblo-magico.png"
        alt="Tecate Pueblo Mágico"
        class="logo-tecate"
      >
    </div>

    <div class="footer-text">
      <p>
        ©SIMPINNA | Sistema Municipal de Protección Integral de los Derechos de las<br>
        Niñas, Niños y Adolescentes
      </p>
    </div>

    <div class="footer-spacer" aria-hidden="true"></div>

  </div>
</footer>